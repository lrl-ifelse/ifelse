package org.ifelse.points;

import org.ifelse.vl.FlowBox;
import org.ifelse.vl.FlowPoint;

public class SqlQuery extends FlowPoint {
    @Override
    public void run(FlowBox flowBox) throws Exception {




        flowBox.next();
    }
}
