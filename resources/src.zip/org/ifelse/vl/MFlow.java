package org.ifelse.vl;

/**
 * Created by dizhanbin on 18/7/16.
 */

public class MFlow {


    public int event;
    public String name;
    public String alia;

    public MFlow(int eventid,String name,String alia){

        this.event = eventid;
        this.name = name;
        this.alia = alia;

    }


}
