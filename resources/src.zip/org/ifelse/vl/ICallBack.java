package org.ifelse.vl;

public interface ICallBack<K,V> {
    public void on(K k, V v);
}
